import pygame

pygame.init()

w,h=1530,800
win=pygame.display.set_mode((w,h))
run=True

# Player and bullet img
player=pygame.image.load('game/player.png').convert_alpha()
bullet=pygame.image.load('game/bullet.png').convert_alpha()
player_1=pygame.transform.scale(player,(player.get_width()//5,player.get_height()//8))
player_2=pygame.transform.flip(player_1,True,False)
bullet_1=pygame.transform.rotate(pygame.transform.scale(bullet,
                                                        (bullet.get_width()//15,bullet.get_height()//20)),270)
bullet_2=pygame.transform.rotate(pygame.transform.scale(bullet,
                                                        (bullet.get_width()//15,bullet.get_height()//20)),90)
pspeed=2.5
bspeed=5
p1r=player_1.get_rect(topleft=(0,100))
p2r=player_2.get_rect(bottomleft=(w-100,h-100))
b1c,b2c=[],[]
clock=pygame.time.Clock()

# Player health
p1h=100
p2h=100
damage=10

#colors
bg='darkgreen'
win_color='red'
health_color='black'

# Font for text display
pygame.font.init()
font=pygame.font.SysFont('comicsansms',35,italic=True,bold=True)
winner_text=""

# Player movement
def movement(k,p1_rect,p2_rect):
    # Player 1 movement
    if k[pygame.K_w] and p1_rect.top>0:
        p1_rect.y-=pspeed
    if k[pygame.K_s] and p1_rect.bottom<h:
        p1_rect.y+=pspeed
    if k[pygame.K_d] and p1_rect.right<w//2:
        p1_rect.x+=pspeed
    if k[pygame.K_a] and p1_rect.left>0:
        p1_rect.x-=pspeed
    
    # Player 2 movement
    if k[pygame.K_UP] and p2_rect.top>0:
        p2_rect.y-=pspeed
    if k[pygame.K_DOWN] and p2_rect.bottom<h:
        p2_rect.y+=pspeed
    if k[pygame.K_RIGHT] and p2_rect.right<w:
        p2_rect.x+=pspeed
    if k[pygame.K_LEFT] and p2_rect.left>w//2:
        p2_rect.x-=pspeed

while run:
    # Event loop
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
        
        if event.type==pygame.KEYDOWN:
            if event.key==pygame.K_LSHIFT:
                if len(b1c)<5:
                    # Create a NEW rect for each bullet
                    bullet_rect_1=bullet_1.get_rect()
                    bullet_rect_1.midleft=p1r.midright
                    b1c.append(bullet_rect_1)
                
            if event.key==pygame.K_RSHIFT:
                if len(b2c)<5:
                    # Create a NEW rect for each bullet
                    bullet_rect_2=bullet_2.get_rect()
                    bullet_rect_2.midright=p2r.midleft
                    b2c.append(bullet_rect_2)

    # Bullet move
    for bullet_rect in b1c:
        bullet_rect.x+=bspeed
    for bullet_rect in b2c:
        bullet_rect.x-=bspeed

    # Bullet collision and cleanup
    new_b1c=[]
    for bullet_rect in b1c:
        if bullet_rect.colliderect(p2r):
            p2h-=damage
        elif bullet_rect.right<w:
            new_b1c.append(bullet_rect)
    b1c=new_b1c

    new_b2c=[]
    for bullet_rect in b2c:
        if bullet_rect.colliderect(p1r):
            p1h-=damage
        elif bullet_rect.left>0:
            new_b2c.append(bullet_rect)
    b2c=new_b2c

    # Check for a winner
    if p1h<=0:
        winner_text="Player 2   Wins!"
        run=False
    elif p2h<=0:
        winner_text="Player 1   Wins!"
        run=False
        
    # Player movement
    keys=pygame.key.get_pressed()
    movement(keys,p1r,p2r)

    # Drawing
    win.fill(bg)
    win.blit(player_1,p1r)
    win.blit(player_2,p2r)
    
    for i in b1c:
        win.blit(bullet_1,i)
    for i in b2c:
        win.blit(bullet_2,i)
        
    # Display health
    p1_health_text=font.render(f'P1 Health:{p1h}',True,health_color)
    p2_health_text=font.render(f'P2 Health:{p2h}',True,health_color)
    win.blit(p1_health_text,(10,10))
    win.blit(p2_health_text,(w-p2_health_text.get_width()-10,10))
    pygame.display.update()
    clock.tick(120)

pygame.font.init()
font=pygame.font.SysFont('magneto',50,bold=True)
# Display winner text after loop ends
if winner_text:
    final_text=font.render(winner_text,True,win_color)
    text_rect=final_text.get_rect(center=(w//2,h//2))
    win.blit(final_text, text_rect)
    pygame.display.update()
    pygame.time.wait(3500)

pygame.quit()
