import pickle

car_price = {
    'Delhi': {
        'Tata Nexon': 1050000,
        'Tata Harrier': 1600000,
        'Tata Safari': 1850000,
        'Tata Altroz': 650000,
        'Tata Tiago': 570000,
        'Tata Harrier EV': 2200000,
        'Tata Tiago EV': 870000,
        'Tata Nexon EV': 1450000,
        'Tata Punch': 600000,
        'Tata Punch EV': 1100000
    },
    'Chennai': {
        'Tata Nexon': 1075000,
        'Tata Harrier': 1650000,
        'Tata Safari': 1900000,
        'Tata Altroz': 670000,
        'Tata Tiago': 585000,
        'Tata Harrier EV': 2250000,
        'Tata Tiago EV': 890000,
        'Tata Nexon EV': 1480000,
        'Tata Punch': 615000,
        'Tata Punch EV': 1120000
    },
    'Mumbai': {
        'Tata Nexon': 1090000,
        'Tata Harrier': 1680000,
        'Tata Safari': 1930000,
        'Tata Altroz': 685000,
        'Tata Tiago': 600000,
        'Tata Harrier EV': 2280000,
        'Tata Tiago EV': 905000,
        'Tata Nexon EV': 1500000,
        'Tata Punch': 630000,
        'Tata Punch EV': 1135000
    },
    'Banglore': {
        'Tata Nexon': 1120000,
        'Tata Harrier': 1710000,
        'Tata Safari': 1980000,
        'Tata Altroz': 700000,
        'Tata Tiago': 615000,
        'Tata Harrier EV': 2330000,
        'Tata Tiago EV': 920000,
        'Tata Nexon EV': 1530000,
        'Tata Punch': 645000,
        'Tata Punch EV': 1150000
    },
    'Kolkata': {
        'Tata Nexon': 1060000,
        'Tata Harrier': 1630000,
        'Tata Safari': 1880000,
        'Tata Altroz': 660000,
        'Tata Tiago': 575000,
        'Tata Harrier EV': 2230000,
        'Tata Tiago EV': 880000,
        'Tata Nexon EV': 1460000,
        'Tata Punch': 605000,
        'Tata Punch EV': 1110000
    },
    'Lucknow': {
        'Tata Nexon': 1045000,
        'Tata Harrier': 1610000,
        'Tata Safari': 1860000,
        'Tata Altroz': 645000,
        'Tata Tiago': 560000,
        'Tata Harrier EV': 2210000,
        'Tata Tiago EV': 865000,
        'Tata Nexon EV': 1440000,
        'Tata Punch': 590000,
        'Tata Punch EV': 1095000
    }
}

with open('new_tata.dat', 'rb') as file:
    '''for i in car_price:
        pickle.dump([i,car_price[i]],file)
    '''
    try:
        while True:
            a=pickle.load(file)
            print(a,"\n")
    except EOFError:
        print("that's all")
