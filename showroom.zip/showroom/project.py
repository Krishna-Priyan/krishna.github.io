from tkinter import *
from pickle import *
from tkinter import messagebox

w=Tk()
w.configure(bg='black')
w.title('CAR SHOWROOM')
r,c=0,0
f=('inkfree',35)

#welcome text
def welcome():
    la=Label(w,text='WELCOME TO TATA SHOWROOM',fg='red',bg='black',font=f)
    b=Button(w,text='NEXT',font=f,fg='steelblue',bg='black',command=cf)
    la.grid(row=r,column=c,sticky='new')
    b.grid(row=r+1,column=c,sticky='ews')

#customerform
def cf():
    for i in w.winfo_children():
        i.grid_forget()
    global ne,be,ee
    nl=Label(w,text='NAME',font=f,fg='cyan2',bg='black')
    el=Label(w,text='EMAIL',font=f,fg='cyan2',bg='black')
    bl=Label(w,text='BUDGET',font=f,fg='cyan2',bg='black')
    s=Button(w,text='SUBMIT',font=f,fg='seagreen',bg='black',command=details)
    ne=Entry(w,font=f,fg='red2',bg='black',insertbackground='aquamarine')
    be=Entry(w,font=f,fg='red2',bg='black',insertbackground='aquamarine')
    ee=Entry(w,font=f,fg='red2',bg='black',insertbackground='aquamarine')
    nl.grid(row=r,column=c,sticky='ew')
    bl.grid(row=r+2,column=c,sticky='ew')
    el.grid(row=r+1,column=c,sticky='ew')
    ne.grid(row=r,column=c+1,sticky='ew')
    be.grid(row=r+2,column=c+1,sticky='ew')
    ee.grid(row=r+1,column=c+1,sticky='ew')
    s.grid(row=r+3,column=c,sticky='ew')

#checking details
def details():
    global ne,be,ee
    nd=ne.get()
    ed=ee.get()
    bd=eval(be.get())
    a=0
    if  not ed.endswith('@gmail.com'):
        messagebox.showwarning('WARNING','CHECK EMAIL ONCE')
        a=1
    elif len(nd)<2:
        messagebox.showwarning('WARNING','check name')
        a=1
    elif bd<1000000:
        messagebox.showwarning('WARNING','NO CAR LESS THAN 10 LAHKS RUPEES')
        a=1
    elif a!=1:
        validate()

#validating details
def validate():
    global l
    for i in w.winfo_children():
        i.grid_forget()
    l=Listbox(w,font=f,fg='turquoise',bg='black',selectmode=BROWSE)
    fo=open('showroom/tata.dat','rb')
    c=Button(w,text='BOOK',font=f,fg='springgreen',bg='black',command=book)
    try:
        while True:
            d=load(fo)
            a=float(be.get())
            if a>=500000 and d['price']<=a:
                l.insert(END,[d['model'],d['price']])
    except EOFError:
        fo.close()
        l.grid(column=2,rowspan=len(l)-1,columnspan=2,sticky='ew')
        c.grid(row=l.size(),column=3,sticky='ews')

#booking the chosen car
def book():
    global v,op
    for i in w.winfo_children():
        i.grid_forget()
    con=Button(w,text='CONFIRM',fg='thistle4',bg='black',font=f,command=price)
    pl=Label(w,text='PAYMENT',font=f,fg='cadetblue4',bg='black')
    op=['CASH','LOAN']
    v=StringVar(w)
    po=OptionMenu(w,v,*op)
    po.config(font=f,fg='violetred',bg='black')
    pl.grid(row=r,column=c,sticky='ew')
    po.grid(row=r+1,sticky='ew')
    con.grid(row=r+2,column=c,sticky='ew')

#showing the price to customer and checking for payment method
def price():
    global va,o,p
    p=l.get(l.curselection())
    sv=v.get()
    for i in w.winfo_children():
        i.grid_forget()
    if sv==op[1]:
        la=Label(w,text='LOAN AMOUNT',font=f,fg='dodgerblue',bg='black')
        o=['25%','50%','75%']
        va=StringVar(w)
        om=OptionMenu(w,va,*o)
        om.config(font=f,fg='deeppink',bg='black')
        con=Button(w,text='CONFIRM',font=f,fg='aquamarine',bg='black',command=loan)
        la.grid(row=r,sticky='ew')
        om.grid(row=r+1,sticky='ew')
        con.grid(row=r+2,sticky='ew')
    else:
        final()

#purchase succeful message 
def final():
    for i in w.winfo_children():
        i.grid_forget()
    m=Message(w,text='PURCHASE SUCESSFULL',font=('inkfree',25),fg='magenta2',bg='black')
    m.grid(row=r,sticky='ew')
    a=Button(w,text='BILL',font=f,fg='hotpink',bg='black',command=bill)
    a.grid(row=r+1,sticky='ew')    

#getting loan amount
def loan():
    global amt,tp
    for i in w.winfo_children():
        i.grid_forget()
    if va.get()==o[0]:
        pa=Label(w,text='PRINCIPAL AMOUNT:'+str(0.25*p[-1]),font=f,fg='slategray',bg='black')
        ra=Label(w,text='RATE OF INTREST: 5%',font=f,fg='dimgray',bg='black')
        tl=Label(w,text='TIME PERIOD',font=f,fg='thistle',bg='black')
        t=[2,5,7]
        tp=StringVar(w)
        ti=OptionMenu(w,tp,*t)
        ti.config(font=f,fg='red',bg='black')
        pa.grid(row=r,column=c,sticky='ew')
        ra.grid(row=r+1,column=c,sticky='ew')
        tl.grid(row=r+2,column=c,sticky='ew')
        ti.grid(row=r+2,column=c+1,sticky='ew')
        amt=0.25*p[-1]*0.05
    if va.get()==o[1]:
        pa=Label(w,text='PRINCIPAL AMOUNT:'+str(0.5*p[-1]),font=f,fg='darkgreen',bg='black')
        ra=Label(w,text='RATE OF INTREST: 5%',font=f,fg='violetred2',bg='black')
        t=[2,5,7]
        tp=StringVar(w)
        ti=OptionMenu(w,tp,*t)
        tl=Label(w,text='TIME PERIOD',font=f,fg='thistle',bg='black')
        ti.config(font=f,fg='firebrick1',bg='black')
        pa.grid(row=r,column=c,sticky='ew')
        ra.grid(row=r+1,column=c,sticky='ew')
        tl.grid(row=r+2,column=c,sticky='ew')
        ti.grid(row=r+2,column=c+1,sticky='ew')
        amt=0.5*p[-1]*0.05
    if va.get()==o[2]:
        pa=Label(w,text='PRINCIPAL AMOUNT:'+str(0.75*p[-1]),font=f,fg='magenta2',bg='black')
        ra=Label(w,text='RATE OF INTREST: 5%',font=f,fg='deepskyblue',bg='black')
        t=[2,5,7]
        tp=StringVar(w)
        ti=OptionMenu(w,tp,*t)
        ti.config(font=f,fg='darkturquoise',bg='black')
        tl=Label(w,text='TIME PERIOD',font=f,fg='thistle',bg='black')
        pa.grid(row=r,column=c,sticky='ew')
        ra.grid(row=r+1,column=c,sticky='ew')
        tl.grid(row=r+2,column=c,sticky='ew')
        ti.grid(row=r+2,column=c+1,sticky='ew')
        amt=0.75*p[-1]*0.05
    b=Button(w,text='BILL',font=f,fg='springgreen',bg='black',command=bill)
    b.grid(row=r+3,sticky='ew')

#generating bill for customer
def bill():
    for i in w.winfo_children():
        i.grid_forget()
    n=Label(w,text='NAME',font=f,fg='gold',bg='black')
    n.grid(row=r,column=c,sticky='ew')
    nl=Label(w,text=str(ne.get()).capitalize(),font=f,fg='red',bg='black')    
    mn=Label(w,text='MODEL NAME',font=f,fg='gold',bg='black')
    mn.grid(row=r+1,column=c,sticky='ew')
    mnl=Label(w,text=str(p[0]).capitalize(),font=f,fg='red',bg='black')
    mp=Label(w,text='MODEL PRICE',font=f,fg='gold',bg='black')
    mp.grid(row=r+2,column=c,sticky='ew')
    mpl=Label(w,text=str(p[1]).capitalize(),font=f,fg='red',bg='black')
    pm=Label(w,text='PAYMENT METHOD',font=f,fg='gold',bg='black')
    pm.grid(row=r+3,column=c,sticky='ew')
    pml=Label(w,text=str(v.get()).capitalize(),font=f,fg='red',bg='black')
    dp=Label(w,text='DOWN PAYMENT',font=f,fg='gold',bg='black')
    dp.grid(row=r+4,column=c,sticky='ew')
    dpl=Label(w,text=str(p[1]*0.05).capitalize(),font=f,fg='red',bg='black')
    if v.get()==op[1]:
        ia=Label(w,text='INTREST AMOUNT',font=f,fg='gold',bg='black')
        ial=Label(w,text=round(amt*(float(tp.get())/100),3),font=f,fg='red',bg='black')
        tpl=Label(w,text='TIME PEROID',font=f,fg='gold',bg='black')
        t=Label(w,text=str(tp.get())+'years',font=f,fg='red',bg='black')
        nl.grid(row=r,column=c+1,sticky='ew')
        mnl.grid(row=r+1,column=c+1,sticky='ew')
        mpl.grid(row=r+2,column=c+1,sticky='ew')
        pml.grid(row=r+3,column=c+1,sticky='ew')
        dpl.grid(row=r+4,column=c+1,sticky='ew')
        ia.grid(row=r+5,column=c,sticky='ew')
        ial.grid(row=r+5,column=c+1,sticky='ew')
        tpl.grid(row=r+6,column=c,sticky='ew')
        t.grid(row=r+6,column=c+1,sticky='ew')
        e=Button(w,text='EXIT',font=f,fg='lavender',bg='black',command=w.destroy)
        e.grid(row=r+7,columnspan=2,sticky='ew')
    else:
        nl.grid(row=r,column=c+1,sticky='ew')
        mnl.grid(row=r+1,column=c+1,sticky='ew')
        mpl.grid(row=r+2,column=c+1,sticky='ew')
        pml.grid(row=r+3,column=c+1,sticky='ew')
        dpl.grid(row=r+4,column=c+1,sticky='ew')
        e=Button(w,text='EXIT',font=f,fg='green',bg='black',command=w.destroy)
        e.grid(row=r+5,columnspan=2,sticky='ew')

#calling the function
welcome()
w.mainloop()
