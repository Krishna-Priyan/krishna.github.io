from tkinter import *
from tkinter import messagebox
from pickle import *

win=Tk()
win.config(bg='black')
f=('inkfree',35)
r,c=0,0

def welcome():
    la=Label(win,text='WELCOME TO TATA SHOWROOM',fg='red',bg='black',font=f)
    b=Button(win,text='NEXT',font=f,fg='steelblue',bg='black',command=cf)
    la.grid(row=r,column=c,sticky='new')
    b.grid(row=r+1,column=c,sticky='ews')

def cf():
    for i in win.winfo_children():
        i.grid_forget()
    global l,v,ne,ee,be
    l=['DELHI','CHENNAI','BANGLORE','KOLKATA','MUMBAI']
    v=StringVar(win)
    v.set(l[1])
    nl=Label(win,text='NAME',font=f,fg='cyan2',bg='black')
    el=Label(win,text='EMAIL',font=f,fg='cyan2',bg='black')
    bl=Label(win,text='BUDGET',font=f,fg='cyan2',bg='black')
    s=Button(win,text='SUBMIT',font=f,fg='seagreen',bg='black',command=check)
    ne=Entry(win,font=f,fg='red2',bg='black',insertbackground='aquamarine')
    be=Entry(win,font=f,fg='red2',bg='black',insertbackground='aquamarine')
    ee=Entry(win,font=f,fg='red2',bg='black',insertbackground='aquamarine')
    lo=OptionMenu(win,v,*l)
    lo.configure(font=f,fg='red2',bg='black')
    nl.grid(row=r,column=c,sticky='ew')
    bl.grid(row=r+2,column=c,sticky='ew')
    el.grid(row=r+1,column=c,sticky='ew')
    ne.grid(row=r,column=c+1,sticky='ew')
    ee.grid(row=r+1,column=c+1,sticky='ew')
    be.grid(row=r+2,column=c+1,sticky='ew')
    lo.grid(row=r+4,column=c,sticky='ew')
    s.grid(row=r+4,column=c+1,sticky='ews')

def check():
    for i in win.winfo_children():
        i.grid_forget()
    global ne,ee,be
    nd=ne.get()
    ed=ee.get()
    try:
        bd=float(be.get)
    except ValueError:
        messagebox.showwarning('warning','ENTER A VALID BUDGET')
    if len(nd)>2:
        messagebox.showwarning('warning','check name')
    elif not nd.endswith('@gmail.com'):
        messagebox.showwarning('warning','check email')
    elif bd<1000000:
        messagebox.showwarning('warning','NO CAR UNDER 10 LAKHS')
    else:
        validate()

def validate():
    pass

welcome()
win.mainloop()